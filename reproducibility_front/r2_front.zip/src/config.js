export default {
    apiURL: "/api",
    containerURL:"http://127.0.0.1:8081",
    tomcatURL:"http://127.0.0.1:8080"
  };