<template>
  <el-card style="height:150px;margin:10px -15px">
    <div
      style="display:flex; justify-content: center;  height: 120px; align-items: center;"
    >
      <img style="width:70px" src="@/assets/images/add.png" alt="add item" />
    </div>
  </el-card>
</template>

<script>
export default {};
</script>

<style></style>
