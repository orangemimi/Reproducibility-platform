<style scoped>
.footer {
  background-color: #515a6e;
  height: 60px;
  width: 100%;
  bottom: 0;
  flex: 0 0 auto;
}
.footerTop {
  text-align: center;
  color: white;
  font-weight: bold;
  margin-top: 10px;
}
.footerBottom {
  text-align: center;
  color: white;
  font-size: 0.8em;
}
</style>
<template>
  <div class="container">
    <div class="footer">
      <h2 class="footerTop">
        <i>Open Geographic Modeling and Simulation</i>
      </h2>
      <p class="footerBottom">
        Copyright © 2013-2020 OpenGMS. All rights reserved.
      </p>
    </div>
  </div>
</template>
<script>
export default {};
</script>
